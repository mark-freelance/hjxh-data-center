package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.SpGoodslx;

/**
 * (SpGoodslx)表服务接口
 *
 * @author makejava
 * @since 2021-11-05 18:28:24
 */
public interface SpGoodslxService extends IService<SpGoodslx> {

}

