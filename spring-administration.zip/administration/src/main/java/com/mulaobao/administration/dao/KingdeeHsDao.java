package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.KingdeeHs;
import org.apache.ibatis.annotations.Mapper;

/**
 * (KingdeeHs)表数据库访问层
 *
 * @author makejava
 * @since 2021-12-22 10:14:01
 */
@Mapper
public interface KingdeeHsDao extends BaseMapper<KingdeeHs> {

}

