package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.PddXssj;

/**
 * (PddXssj)表服务接口
 *
 * @author makejava
 * @since 2021-09-16 17:42:30
 */
public interface PddXssjService extends IService<PddXssj> {

}

