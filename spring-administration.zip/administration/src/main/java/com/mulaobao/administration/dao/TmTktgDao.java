package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.TmTktg;
import org.apache.ibatis.annotations.Mapper;

/**
 * (TmTktg)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:43:26
 */
@Mapper
public interface TmTktgDao extends BaseMapper<TmTktg> {

}

