package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.DpCkwjs;

/**
 * (DpCkwjs)表服务接口
 *
 * @author makejava
 * @since 2022-01-04 15:59:44
 */
public interface DpCkwjsService extends IService<DpCkwjs> {

}

