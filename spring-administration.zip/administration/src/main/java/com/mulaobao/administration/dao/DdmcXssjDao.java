package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.DdmcXssj;
import org.apache.ibatis.annotations.Mapper;

/**
 * (DdmcXssj)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-18 18:32:41
 */
@Mapper
public interface DdmcXssjDao extends BaseMapper<DdmcXssj> {

}

