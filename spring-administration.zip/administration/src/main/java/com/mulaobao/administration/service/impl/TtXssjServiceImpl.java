package com.mulaobao.administration.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mulaobao.administration.dao.TtXssjDao;
import com.mulaobao.administration.entity.TtXssj;
import com.mulaobao.administration.service.TtXssjService;
import org.springframework.stereotype.Service;

/**
 * (TtXssj)表服务实现类
 *
 * @author makejava
 * @since 2021-09-16 17:44:06
 */
@Service("ttXssjService")
public class TtXssjServiceImpl extends ServiceImpl<TtXssjDao, TtXssj> implements TtXssjService {

}

