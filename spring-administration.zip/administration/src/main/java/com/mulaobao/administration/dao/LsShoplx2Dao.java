package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.LsShoplx2;
import org.apache.ibatis.annotations.Mapper;

/**
 * (LsShoplx2)表数据库访问层
 *
 * @author makejava
 * @since 2021-10-20 11:14:12
 */
@Mapper
public interface LsShoplx2Dao extends BaseMapper<LsShoplx2> {

}

