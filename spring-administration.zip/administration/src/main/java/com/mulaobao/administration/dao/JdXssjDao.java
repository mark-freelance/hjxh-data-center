package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.JdXssj;
import org.apache.ibatis.annotations.Mapper;

/**
 * (JdXssj)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:40:47
 */
@Mapper
public interface JdXssjDao extends BaseMapper<JdXssj> {

}

