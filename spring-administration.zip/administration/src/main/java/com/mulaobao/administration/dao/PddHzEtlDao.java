package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.PddHzEtl;
import org.apache.ibatis.annotations.Mapper;

/**
 * (PddHzEtl)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-22 14:33:38
 */
@Mapper
public interface PddHzEtlDao extends BaseMapper<PddHzEtl> {

}

