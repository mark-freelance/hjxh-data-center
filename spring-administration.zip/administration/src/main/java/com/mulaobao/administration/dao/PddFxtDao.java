package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.PddFxt;
import org.apache.ibatis.annotations.Mapper;

/**
 * (PddFxt)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-23 10:37:46
 */
@Mapper
public interface PddFxtDao extends BaseMapper<PddFxt> {

}

