package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.DyXssj;
import org.apache.ibatis.annotations.Mapper;

/**
 * (DyXssj)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 15:04:36
 */
@Mapper
public interface DyXssjDao extends BaseMapper<DyXssj> {

}

