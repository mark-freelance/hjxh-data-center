package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.TmZtc;
import org.apache.ibatis.annotations.Mapper;

/**
 * (TmZtc)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:43:52
 */
@Mapper
public interface TmZtcDao extends BaseMapper<TmZtc> {

}

