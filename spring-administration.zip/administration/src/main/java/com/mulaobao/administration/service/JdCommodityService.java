package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.JdCommodity;

/**
 * (JdCommodity)表服务接口
 *
 * @author makejava
 * @since 2021-12-31 11:01:49
 */
public interface JdCommodityService extends IService<JdCommodity> {

}

