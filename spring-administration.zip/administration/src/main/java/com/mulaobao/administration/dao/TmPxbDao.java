package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.TmPxb;
import org.apache.ibatis.annotations.Mapper;

/**
 * (TmPxb)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:43:16
 */
@Mapper
public interface TmPxbDao extends BaseMapper<TmPxb> {

}

