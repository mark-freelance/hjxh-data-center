package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.LsShoplx2;

/**
 * (LsShoplx2)表服务接口
 *
 * @author makejava
 * @since 2021-10-20 11:14:12
 */
public interface LsShoplx2Service extends IService<LsShoplx2> {

}

