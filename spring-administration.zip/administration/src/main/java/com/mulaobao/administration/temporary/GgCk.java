package com.mulaobao.administration.temporary;

import lombok.Data;

@Data
public class GgCk {

    private String goodsbh;

    private String goodsname;


    private Integer qmkc;

    private Integer num;

    private Integer rxl;

    private Integer zcr;
}
