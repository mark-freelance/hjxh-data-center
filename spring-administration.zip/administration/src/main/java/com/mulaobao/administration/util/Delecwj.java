package com.mulaobao.administration.util;

import com.alibaba.excel.EasyExcel;
import com.mulaobao.administration.entity.TmPxb;
import com.mulaobao.administration.listener.TmPxbListener;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Delecwj {

    //删除文件夹
    public static void delFolder(String folderPath) {
        try {
            delAllFile(folderPath); //删除完里面所有内容
            String filePath = folderPath;
            filePath = filePath.toString();
            java.io.File myFilePath = new java.io.File(filePath);
            myFilePath.delete(); //删除空文件夹
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //删除指定文件夹下的所有文件

    public static boolean delAllFile(String path) {
        boolean flag = false;
        File file = new File(path);
        if (!file.exists()) {
            return flag;
        }
        if (!file.isDirectory()) {
            return flag;
        }
        String[] tempList = file.list();
        File temp = null;
        for (int i = 0; i < tempList.length; i++) {
            if (path.endsWith(File.separator)) {
                temp = new File(path + tempList[i]);
            } else {
                temp = new File(path + File.separator + tempList[i]);
            }
            if (temp.isFile()) {
                temp.delete();
            }
            if (temp.isDirectory()) {
                delAllFile(path + "/" + tempList[i]);//先删除文件夹里面的文件
                delFolder(path + "/" + tempList[i]);//再删除空文件夹
                flag = true;
            }
        }
        return flag;
    }



    //获取文件名
        public static String [] getFileName(String path)
        {
            File file = new File(path);
            String [] fileName = file.list();
            return fileName;
        }

        public static void getAllFileName(String path, ArrayList<String> fileName)
        {
            File file = new File(path);
            File [] files = file.listFiles();
            String [] names = file.list();
            if(names != null)
                fileName.addAll(Arrays.asList(names));
            for(File a:files)
            {
                if(a.isDirectory())
                {
                    getAllFileName(a.getAbsolutePath(),fileName);
                }
            }
        }
        public static void main(String[] args)
        {

        }

}
