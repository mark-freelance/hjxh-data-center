package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.SpGoodssale;

/**
 * (SpGoodssale)表服务接口
 *
 * @author makejava
 * @since 2021-11-05 18:28:11
 */
public interface SpGoodssaleService extends IService<SpGoodssale> {

}

