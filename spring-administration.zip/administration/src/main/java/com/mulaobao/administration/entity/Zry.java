package com.mulaobao.administration.entity;

import lombok.Data;

@Data
public class Zry {

        private String zz;
        private String zyname;
        private String shop [];
        private String date;
}
