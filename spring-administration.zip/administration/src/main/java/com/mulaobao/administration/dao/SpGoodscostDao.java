package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.SpGoodscost;
import org.apache.ibatis.annotations.Mapper;

/**
 * (SpGoodscost)表数据库访问层
 *
 * @author makejava
 * @since 2021-11-05 18:28:36
 */
@Mapper
public interface SpGoodscostDao extends BaseMapper<SpGoodscost> {

}

