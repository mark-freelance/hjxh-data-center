package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.SpGoodslx;
import org.apache.ibatis.annotations.Mapper;

/**
 * (SpGoodslx)表数据库访问层
 *
 * @author makejava
 * @since 2021-11-05 18:28:23
 */
@Mapper
public interface SpGoodslxDao extends BaseMapper<SpGoodslx> {

}

