package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.PddSstg;
import org.apache.ibatis.annotations.Mapper;

/**
 * (PddSstg)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:42:12
 */
@Mapper
public interface PddSstgDao extends BaseMapper<PddSstg> {

}

