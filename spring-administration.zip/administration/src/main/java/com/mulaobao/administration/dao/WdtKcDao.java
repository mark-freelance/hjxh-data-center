package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.WdtKc;
import org.apache.ibatis.annotations.Mapper;

/**
 * (WdtKc)表数据库访问层
 *
 * @author makejava
 * @since 2021-12-22 10:13:25
 */
@Mapper
public interface WdtKcDao extends BaseMapper<WdtKc> {

}

