package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.JdJdkc;
import org.apache.ibatis.annotations.Mapper;

/**
 * (JdJdkc)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:40:36
 */
@Mapper
public interface JdJdkcDao extends BaseMapper<JdJdkc> {

}

