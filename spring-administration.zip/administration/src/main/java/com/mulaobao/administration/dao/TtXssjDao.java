package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.TtXssj;
import org.apache.ibatis.annotations.Mapper;

/**
 * (TtXssj)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:44:06
 */
@Mapper
public interface TtXssjDao extends BaseMapper<TtXssj> {

}

