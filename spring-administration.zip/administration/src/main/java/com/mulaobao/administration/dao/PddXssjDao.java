package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.PddXssj;
import org.apache.ibatis.annotations.Mapper;

/**
 * (PddXssj)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:42:30
 */
@Mapper
public interface PddXssjDao extends BaseMapper<PddXssj> {

}

