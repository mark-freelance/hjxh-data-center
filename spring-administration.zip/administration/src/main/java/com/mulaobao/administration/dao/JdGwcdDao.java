package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.JdGwcd;
import org.apache.ibatis.annotations.Mapper;

/**
 * (JdGwcd)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:40:19
 */
@Mapper
public interface JdGwcdDao extends BaseMapper<JdGwcd> {

}

