package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.LsProductcomm;

/**
 * (LsProductcomm)表服务接口
 *
 * @author makejava
 * @since 2021-11-27 14:38:34
 */
public interface LsProductcommService extends IService<LsProductcomm> {

}

