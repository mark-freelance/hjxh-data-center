package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.LsProductcomm;
import org.apache.ibatis.annotations.Mapper;

/**
 * (LsProductcomm)表数据库访问层
 *
 * @author makejava
 * @since 2021-11-27 14:38:34
 */
@Mapper
public interface LsProductcommDao extends BaseMapper<LsProductcomm> {

}

