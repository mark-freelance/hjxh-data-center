package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.SpHistory;

/**
 * (SpHistory)表服务接口
 *
 * @author makejava
 * @since 2021-11-06 16:01:07
 */
public interface SpHistoryService extends IService<SpHistory> {

}

