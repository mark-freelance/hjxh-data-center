package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.PddCjtg;
import org.apache.ibatis.annotations.Mapper;

/**
 * (PddCjtg)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:42:01
 */
@Mapper
public interface PddCjtgDao extends BaseMapper<PddCjtg> {

}

