package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.PddMxdp;
import org.apache.ibatis.annotations.Mapper;

/**
 * (PddMxdp)表数据库访问层
 *
 * @author makejava
 * @since 2021-12-02 15:44:06
 */
@Mapper
public interface PddMxdpDao extends BaseMapper<PddMxdp> {

}

