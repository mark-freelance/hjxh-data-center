package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.LsShop;
import org.apache.ibatis.annotations.Mapper;

/**
 * (LsShop)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:41:12
 */
@Mapper
public interface LsShopDao extends BaseMapper<LsShop> {

}

