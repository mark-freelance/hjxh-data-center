package com.mulaobao.administration.temporary;

import lombok.Data;

@Data
public class HzCk {

    private String goodsbh;

    private String goodsname;

    private String Warehouse;

    private Integer qmkc;

    private Integer num;

    private Integer rxl;

    private Integer zcr;

}
