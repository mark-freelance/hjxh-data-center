package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.UserdMenu;

/**
 * (UserdMenu)表服务接口
 *
 * @author makejava
 * @since 2021-09-16 16:21:42
 */
public interface UserdMenuService extends IService<UserdMenu> {

}

