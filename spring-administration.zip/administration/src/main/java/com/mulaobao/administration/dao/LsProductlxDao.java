package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.LsProductlx;
import org.apache.ibatis.annotations.Mapper;

/**
 * (LsProductlx)表数据库访问层
 *
 * @author makejava
 * @since 2021-11-27 14:38:02
 */
@Mapper
public interface LsProductlxDao extends BaseMapper<LsProductlx> {

}

