package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.UserdMenu;
import org.apache.ibatis.annotations.Mapper;

/**
 * (UserdMenu)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 16:21:42
 */
@Mapper
public interface UserdMenuDao extends BaseMapper<UserdMenu> {

}

