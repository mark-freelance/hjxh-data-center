package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.WdtCk;
import org.apache.ibatis.annotations.Mapper;

/**
 * (WdtCk)表数据库访问层
 *
 * @author makejava
 * @since 2021-12-22 10:12:59
 */
@Mapper
public interface WdtCkDao extends BaseMapper<WdtCk> {

}

