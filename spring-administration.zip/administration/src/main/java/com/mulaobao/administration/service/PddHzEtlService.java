package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.PddHzEtl;

/**
 * (PddHzEtl)表服务接口
 *
 * @author makejava
 * @since 2021-09-22 14:33:38
 */
public interface PddHzEtlService extends IService<PddHzEtl> {

}

