package com.mulaobao.administration.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mulaobao.administration.entity.LsEmpsale;

/**
 * (LsEmpsale)表服务接口
 *
 * @author makejava
 * @since 2021-10-19 15:20:02
 */
public interface LsEmpsaleService extends IService<LsEmpsale> {

}

