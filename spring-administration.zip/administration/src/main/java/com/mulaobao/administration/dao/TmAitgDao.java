package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.TmAitg;
import org.apache.ibatis.annotations.Mapper;

/**
 * (TmAitg)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:42:44
 */
@Mapper
public interface TmAitgDao extends BaseMapper<TmAitg> {

}

