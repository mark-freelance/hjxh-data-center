package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.MgjXssj;
import org.apache.ibatis.annotations.Mapper;

/**
 * (MgjXssj)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:41:38
 */
@Mapper
public interface MgjXssjDao extends BaseMapper<MgjXssj> {

}

