package com.mulaobao.administration.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mulaobao.administration.dao.DpCkwjsDao;
import com.mulaobao.administration.entity.DpCkwjs;
import com.mulaobao.administration.service.DpCkwjsService;
import org.springframework.stereotype.Service;

/**
 * (DpCkwjs)表服务实现类
 *
 * @author makejava
 * @since 2022-01-04 15:59:44
 */
@Service("dpCkwjsService")
public class DpCkwjsServiceImpl extends ServiceImpl<DpCkwjsDao, DpCkwjs> implements DpCkwjsService {

}

