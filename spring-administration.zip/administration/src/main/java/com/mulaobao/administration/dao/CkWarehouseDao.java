package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.CkWarehouse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * (CkWarehouse)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-23 16:49:21
 */
@Mapper
public interface CkWarehouseDao extends BaseMapper<CkWarehouse> {


}

