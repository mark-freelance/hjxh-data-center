package com.mulaobao.administration.temporary;

import lombok.Data;

@Data
public class DDmc {
        private String sheng;
        private String ck;
}
