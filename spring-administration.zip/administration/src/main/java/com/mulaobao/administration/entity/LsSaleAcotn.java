package com.mulaobao.administration.entity;

import lombok.Data;

@Data
public class LsSaleAcotn {

    private String [] da1 ;
    private String value;
    private String [] name;
}
