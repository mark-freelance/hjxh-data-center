package com.mulaobao.administration.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mulaobao.administration.entity.TmCjzz;
import org.apache.ibatis.annotations.Mapper;

/**
 * (TmCjzz)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-16 17:43:05
 */
@Mapper
public interface TmCjzzDao extends BaseMapper<TmCjzz> {

}

